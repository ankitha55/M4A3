import mongoose from 'mongoose';
const { Schema } = mongoose;

const blogSchema = new Schema({
  customerName:  String, // String is shorthand for {type: String}
  phoneNumber: String,
  address:   String,
  loanAmount: String,
  interest: String,
  loanTermYears: String,
  loanType: String,
  description: String,
  createdDate: { type: Date, default: Date.now },
  insertedDate: { type: Date, default: Date.now }
  }
);
const Blog = mongoose.model('Blog', blogSchema);
